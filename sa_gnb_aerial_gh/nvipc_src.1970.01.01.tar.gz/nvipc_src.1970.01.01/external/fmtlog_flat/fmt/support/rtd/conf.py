# Sphinx configuration for readthedocs.

import os, sys

master_doc = 'index'
html_theme = 'theme'
html_theme_path = ["."]
