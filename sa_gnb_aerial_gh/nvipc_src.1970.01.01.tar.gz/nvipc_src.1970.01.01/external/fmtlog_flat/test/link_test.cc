#include "lib.h"
#include "../fmtlog.h"

int main() {
  logi("link test: {}", 123);
  libFun(321);
  return 0;
}
