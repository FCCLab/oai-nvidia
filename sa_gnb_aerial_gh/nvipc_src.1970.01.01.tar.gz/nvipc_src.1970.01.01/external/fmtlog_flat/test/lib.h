#pragma once
void libFun(int i);
